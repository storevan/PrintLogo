<?php
/**
 * @Author      : TuanNA
 * @package     Marketplace_Rma_System
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Block\Adminhtml;
use Magento\Backend\Block\Template;
class ListMessages extends Template
{
	protected $_contactFactory;
	protected $_requestFactory;
	protected $_attachmentFactory;
	
    /**
    * @param Context $context
    * @param array $data
    */
    public function __construct(
		\Magebay\PrintLogo\Model\ContactFactory $contactFactory,
		\Magebay\PrintLogo\Model\RequestFactory $requestFactory,
		\Magebay\PrintLogo\Model\AttachmentFactory $attachmentFactory,
        Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
		$this->_contactFactory = $contactFactory;
		$this->_requestFactory = $requestFactory;
		$this->_attachmentFactory = $attachmentFactory;
		
    }
	
    public function getContactId(){
        return $this->getData('id');
    }
	
	public function getContact(){
		$contactId = $this->getContactId();
		return $this->_contactFactory->create()->load($contactId);
	}
}