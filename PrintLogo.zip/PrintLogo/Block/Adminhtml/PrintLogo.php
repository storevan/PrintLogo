<?php
/**
 * @Author      : TuanNA
 * @package     Marketplace_Seller_Business
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Block\Adminhtml;

class PrintLogo extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_PrintLogo';
        $this->_blockGroup = 'Magebay_PrintLogo';
        $this->_headerText = __('PrintLogo');
        // $this->_addButtonLabel = __('Add Seller Business');
        parent::_construct();
		$this->removeButton('add');
    }
}