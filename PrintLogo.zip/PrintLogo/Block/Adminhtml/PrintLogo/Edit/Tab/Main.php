<?php
/**
 * @Author      : TuanNA
 * @package     Magebay_PrintLogo
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Block\Adminhtml\PrintLogo\Edit\Tab;

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements
    \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Backend\Block\Widget\Form\Renderer\Fieldset
     */
    protected $_rendererFieldset;
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_customerFactory;    
    protected $_resource;   

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Magento\Backend\Block\Widget\Form\Renderer\Fieldset $rendererFieldset,
        \Magento\Customer\Model\CustomerFactory $customerFactory,   
        \Magento\Framework\App\ResourceConnection $resource,  
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_rendererFieldset = $rendererFieldset;
        $this->_customerFactory = $customerFactory;  
        $this->_resource = $resource;  
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /* @var $model \Magefan\Blog\Model\Category */
        $model = $this->_coreRegistry->registry('current_model');

        /*
         * Checking if user have permissions to save information
         */
        $isElementDisabled = !$this->_isAllowedAction('Magebay_PrintLogo::printlogo');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('printlogo_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('General Information')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }
	
        $fieldset->addField(
            'business_name',
            'text',
            [
                'name' => 'business_name',
                'label' => __('Business Name'),
                'title' => __('Business Name'),
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'first_name',
            'text',
            [
                'name' => 'first_name',
                'label' => __('First Name'),
                'title' => __('First Name'),
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'last_name',
            'text',
            [
                'name' => 'last_name',
                'label' => __('Last Name'),
                'title' => __('Last Name'),
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'street',
            'text',
            [
                'name' => 'street',
                'label' => __('Street'),
                'title' => __('Street'),
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'zip_code',
            'text',
            [
                'name' => 'zip_code',
                'label' => __('Zip Code'),
                'title' => __('Zip Code'),
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'city',
            'text',
            [
                'name' => 'city',
                'label' => __('City'),
                'title' => __('City'),
                
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Email'),
                'title' => __('Email'),
                
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$directory = $objectManager->create('\Magento\Directory\Block\Data');
		$countryOptions = array();
		$countries = $directory->getCountryCollection()
                ->setForegroundCountries($directory->getTopDestinations())
                ->toOptionArray();
				// echo '<pre>'; print_r($countries);
		foreach($countries as $country){
			// $countryOptions[$country['value']] = $country['label'];
			if($country['value'] == $model->getCountryId()){
				$model->setData('country_name', $country['label']);
			}
		}
		$fieldset->addField(
            'country_name',
            'text',
            [
                'name' => 'country_name',
                'label' => __('Country'),
                'title' => __('Country'),
				'readonly' => true,
				// 'options' => $countryOptions,
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'telephone',
            'text',
            [
                'name' => 'telephone',
                'label' => __('Telephone'),
                'title' => __('Telephone'),
                
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'gmap', 
            'text', 
            [
                'name' => 'gmap',
                'label' => __('Map'),
                'title' => __('Map'),
                
                'disabled' => $isElementDisabled                 
            ]
        )->setRenderer($this->_rendererFieldset->setTemplate('Magebay_PrintLogo::gmap.phtml'));   
        
        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '0' : '1');
        }                       
        $this->_eventManager->dispatch('magebay_printlogo_printlogo_edit_tab_main_prepare_form', ['form' => $form]);

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('General Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('General Information');
    }

    /**
     * Returns status flag about this tab can be shown or not
     *
     * @return bool
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Returns status flag about this tab hidden or not
     *
     * @return bool
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}