<?php
/**
 * @Author      : TuanNA
 * @package     Magebay_PrintLogo
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Block\Adminhtml\PrintLogo\Edit\Tab;

class Request extends \Magento\Backend\Block\Widget\Form\Generic implements
    \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Backend\Block\Widget\Form\Renderer\Fieldset
     */
    protected $_rendererFieldset;
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_customerFactory;    
    protected $_resource;
	protected $_helper;	

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Magento\Backend\Block\Widget\Form\Renderer\Fieldset $rendererFieldset,
        \Magento\Customer\Model\CustomerFactory $customerFactory,   
        \Magento\Framework\App\ResourceConnection $resource,
		\Magento\Backend\Helper\Data $helper,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_rendererFieldset = $rendererFieldset;
        $this->_customerFactory = $customerFactory;  
        $this->_resource = $resource;
		$this->_helper = $helper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /* @var $model \Magefan\Blog\Model\Category */
        $model = $this->_coreRegistry->registry('current_model');

        /*
         * Checking if user have permissions to save information
         */
        $isElementDisabled = !$this->_isAllowedAction('Magebay_PrintLogo::printlogo');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('printlogo_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Message')]);
		
		$printlogoRequest = $model->getPrintLogoRequest();
		if($printlogoRequest){
			$model->setData("message", $printlogoRequest->getMessage());
		}
	
        $fieldset->addField(
            'message',
            'textarea',
            [
                'name' => 'message',
                'label' => __('Message'),
                'title' => __('Message'),
				'readonly' => true,
                'disabled' => $isElementDisabled
            ]
        );
		
		$fieldsetDesigns = $form->addFieldset('designs_fieldset', ['legend' => __('Designs')]);
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
		$currentStore = $storeManager->getStore();
		$mediaUrl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
		// $mediaDirectory = $objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
		if($printlogoRequest){
			$designs = $printlogoRequest->getAttachment()->addFieldToFilter('file_type', 'design');
			if(count($designs)){
				foreach($designs as $index=>$attachment){
					$fieldName = 'attachment_'.$index;
					// $filePath = $mediaDirectory->getAbsolutePath($attachment->getFilePath());
					$filePath = $mediaUrl.$attachment->getFilePath();
					$image = '<a href="'.$filePath.'" onclick="imagePreview(\''.$fieldName.'_image'.'\'); return false;">';
					$image .= '<img src="'.$filePath.'" id="'.$fieldName.'_image'.'" height="22" width="22">';
					$image .= '</a>';
					$downloadUrl = $this->_helper->getUrl('magebay/printlogo/download',['id'=>$attachment->getId()]);
					$downloadLink = '<a target="_blank" href="'.$downloadUrl.'" style="margin-left: 50px;">'.$attachment->getFileName().'</a>';
					
					$fieldsetDesigns->addField(
						$fieldName,
						'label',
						[
							'name' => $fieldName,
							'after_element_html' => $image.$downloadLink,
							'disabled' => $isElementDisabled
						]
					);
				}
			}
		}
		
		$fieldsetLogos = $form->addFieldset('logos_fieldset', ['legend' => __('Logos')]);
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		// $mediaDirectory = $objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
		if($printlogoRequest){
			$logos = $printlogoRequest->getAttachment()->addFieldToFilter('file_type', 'logo');
			if(count($logos)){
				foreach($logos as $index=>$attachment){
					$fieldName = 'attachment_'.$index;
					// $filePath = $mediaDirectory->getAbsolutePath($attachment->getFilePath());
					$filePath = $mediaUrl.$attachment->getFilePath();
					$image = '<a href="'.$filePath.'" onclick="imagePreview(\''.$fieldName.'_image'.'\'); return false;">';
					$image .= '<img src="'.$filePath.'" id="'.$fieldName.'_image'.'" height="22" width="22">';
					$image .= '</a>';
					$downloadUrl = $this->_helper->getUrl('magebay/printlogo/download',['id'=>$attachment->getId()]);
					$downloadLink = '<a target="_blank" href="'.$downloadUrl.'" style="margin-left: 50px;">'.$attachment->getFileName().'</a>';
					
					$fieldsetLogos->addField(
						$fieldName,
						'label',
						[
							'name' => $fieldName,
							'after_element_html' => $image.$downloadLink,
							'disabled' => $isElementDisabled
						]
					);
				}
			}
		}
		
        $fieldset->addField(
            'gmap', 
            'text', 
            [
                'name' => 'gmap',
                'label' => __('Map'),
                'title' => __('Map'),
                'required' => true,
                'disabled' => $isElementDisabled                 
            ]
        )->setRenderer($this->_rendererFieldset->setTemplate('Magebay_PrintLogo::gmap.phtml'));   
        
        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '0' : '1');
        }                       
        $this->_eventManager->dispatch('magebay_printlogo_printlogo_edit_tab_main_prepare_form', ['form' => $form]);

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Request Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Request Information');
    }

    /**
     * Returns status flag about this tab can be shown or not
     *
     * @return bool
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Returns status flag about this tab hidden or not
     *
     * @return bool
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}