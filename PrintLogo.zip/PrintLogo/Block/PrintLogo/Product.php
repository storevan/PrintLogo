<?php
/**
 * @Author      : TuanNA
 * @package     Magebay_PrintLogo
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Block\PrintLogo;

class Product extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    protected $_customerFactory;  
    protected $_resource; 
            
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
		\Magento\Customer\Model\Session $customerSession,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\App\ResourceConnection $resource,
        array $data = []
    ) {
	$this->_customerSession = $customerSession;
        $this->_customerFactory = $customerFactory;
	$this->_resource = $resource;
        parent::__construct($context, $data); 
    }
}
?>