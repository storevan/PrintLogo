<?php
/**
 * @Author      : TuanNA
 * @package     Marketplace_Seller_Business
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Controller\Adminhtml;

class PrintLogo extends Actions
{
	/**
	 * Form session key
	 * @var string
	 */
    protected $_formSessionKey  = 'magebay_printlogo_form_data';

    /**
     * Allowed Key
     * @var string
     */
    protected $_allowedKey      = 'Magebay_PrintLogo::printlogo';

    /**
     * Model class name
     * @var string
     */
    protected $_modelClass      = 'Magebay\PrintLogo\Model\Contact';

    /**
     * Active menu key
     * @var string
     */
    protected $_activeMenu      = 'Magebay_PrintLogo::printlogo';

    /**
     * Status field name
     * @var string
     */
    protected $_statusField     = 'status';
}