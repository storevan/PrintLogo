<?php
namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

class Delete extends \Magebay\PrintLogo\Controller\Adminhtml\PrintLogo
{

}