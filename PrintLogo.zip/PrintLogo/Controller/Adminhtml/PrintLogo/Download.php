<?php
namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;

class Download extends \Magento\Backend\App\Action
{
	protected $resultRawFactory;
	protected $fileFactory;
	protected $_attachmentFactory;
	
	public function __construct(
        \Magento\Framework\Controller\Result\RawFactory $resultRawFactory,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
		\Magebay\PrintLogo\Model\AttachmentFactory $attachmentFactory,
        \Magento\Backend\App\Action\Context $context
    ) {
        $this->resultRawFactory      = $resultRawFactory;
        $this->fileFactory           = $fileFactory;
		$this->_attachmentFactory      = $attachmentFactory;
        parent::__construct($context);
    }
    public function execute()
    {
		$id = $this->getRequest()->getParam('id','');
		if($id == '')
		{
			return false;
		}
		$attachment = $this->_attachmentFactory->create()->load($id);
		$content['type'] = 'filename';
		$content['value'] = $attachment->getFilePath();
        $this->fileFactory->create(
            $attachment->getFileName(),
            $content, //content here. it can be null and set later 
            DirectoryList::MEDIA,
            'application/octet-stream'
        );
        $resultRaw = $this->resultRawFactory->create();
        return $resultRaw;
    }
}