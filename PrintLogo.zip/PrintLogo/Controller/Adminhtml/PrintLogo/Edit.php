<?php
namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

class Edit extends \Magebay\PrintLogo\Controller\Adminhtml\PrintLogo
{

}