<?php
namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

class Grid extends \Magebay\PrintLogo\Controller\Adminhtml\PrintLogo
{

}