<?php
namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

class Index extends \Magebay\PrintLogo\Controller\Adminhtml\PrintLogo
{

}