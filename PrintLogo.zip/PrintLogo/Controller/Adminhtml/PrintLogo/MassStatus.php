<?php
namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

class MassStatus extends \Magebay\PrintLogo\Controller\Adminhtml\PrintLogo
{

}