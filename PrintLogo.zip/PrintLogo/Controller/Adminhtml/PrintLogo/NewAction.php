<?php
namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

class NewAction extends \Magebay\PrintLogo\Controller\Adminhtml\PrintLogo
{

}