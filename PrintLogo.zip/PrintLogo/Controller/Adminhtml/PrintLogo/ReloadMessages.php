<?php

namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;

class ReloadMessages extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
    /**
     * Result page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
	 
    protected $_resultPageFactory;
	 /**
     * Result page factory
     *
     * @var \Magento\Framework\Controller\Result\JsonFactory;
     */
	protected $_resultJsonFactory;
	/**
     * @var \Magento\Customer\Model\Session
     */
	 
	function __construct
	(
		Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
		JsonFactory $resultJsonFactory
	)
	{
		parent::__construct($context);
		$this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
		$this->_resultJsonFactory = $resultJsonFactory;
	}

    public function execute()
    {
		$id = $this->getRequest()->getParam('id');
		$html = $this->_view->getLayout()->createBlock('Magebay\PrintLogo\Block\Adminhtml\ListMessages')->setData('id', $id)->setTemplate('Magebay_PrintLogo::reload_messages.phtml')->toHtml();
		
        $resultJson = $this->_resultJsonFactory->create();
        // return $resultJson->setData([
			// $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result),
        // ]);
		return $resultJson->setData($html);
    }
    protected function _isAllowed()
    {
        return true;
    }
}