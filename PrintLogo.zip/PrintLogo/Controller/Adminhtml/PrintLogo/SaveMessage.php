<?php

namespace Magebay\PrintLogo\Controller\Adminhtml\PrintLogo;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;

class SaveMessage extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
    /**
     * Result page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
	 
    protected $_resultPageFactory;
	 /**
     * Result page factory
     *
     * @var \Magento\Framework\Controller\Result\JsonFactory;
     */
	protected $_resultJsonFactory;
	/**
     * @var \Magento\Customer\Model\Session
     */
	protected $_customerSession;
	protected $_authSession;
	protected $_requestFactory;
	protected $_attachmentFactory;
	protected $_contactFactory;
	 
	function __construct
	(
		Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
		JsonFactory $resultJsonFactory,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Backend\Model\Auth\Session $authSession,
		\Magebay\PrintLogo\Model\RequestFactory $requestFactory,
		\Magebay\PrintLogo\Model\AttachmentFactory $attachmentFactory,
		\Magebay\PrintLogo\Model\ContactFactory $contactFactory
	)
	{
		parent::__construct($context);
		$this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
		$this->_resultJsonFactory = $resultJsonFactory;
		$this->_customerSession = $customerSession;
		$this->_authSession = $authSession;
		$this->_requestFactory = $requestFactory;
		$this->_attachmentFactory = $attachmentFactory;
		$this->_contactFactory = $contactFactory;
	}

    public function execute()
    {
		$data = $this->getRequest()->getPostValue();
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$result = ['type'=>'success', 'alert'=>'Saved message successfully.'];
		try{
			/** save message */
			$time = $objectManager->create('Magento\Framework\Stdlib\DateTime\Timezone');
			$message = $this->_requestFactory->create();
			if($data['message']){
				$message->setData('contact_id', $data['id']);
				$message->setData('subject', $data['subject']);
				$message->setData('message', $data['message']);
				$message->setData('reply_user_id', $this->_authSession->getUser()->getUserId());
				$message->setData('created', date('Y-m-d H:i:s',$time->scopeTimeStamp()));
				$message->setData('status', 1);
				$message->save();
			}
			else{
				$result = ['type'=>'warning', 'alert'=>'Please enter your message!'];
			}
				
			/** save attachment */
			if($message->getId()){
				$attachmentDir = array();
				$path_file = 'Magebay/PrintLogo/Attachment';
				if (count($_FILES)) {
					foreach($_FILES as $_itemfile=>$_itemfilevalue){
						if(!$_itemfilevalue['error']){
							$uploader = $this->_objectManager->create(
								'Magento\MediaStorage\Model\File\Uploader',
								['fileId' => $_itemfile]
							);

							$uploader->addValidateCallback('attachment_'.$_itemfile, $this, 'validateUploadFile');
							$uploader->setAllowRenameFiles(true);
							$uploader->setFilesDispersion(true);

							/** @var \Magento\Framework\Filesystem\Directory\Read $mediaDirectory */
							$mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
							$resultFile = $uploader->save($mediaDirectory->getAbsolutePath($path_file));
							$attachment = $this->_attachmentFactory->create();
							$attachment->setData('request_id', $message->getId());
							$attachment->setData('file_path', $path_file . $resultFile['file']);
							$attachment->setData('file_name', $_itemfilevalue['name']);
							$attachment->setData('file_type', 'reply');
							$attachment->save();
							$attachmentDir[] = $mediaDirectory->getAbsolutePath($path_file . $resultFile['file']);
						}
					}
				}
				/** Send Mail */
				$contact = $this->_contactFactory->create()->load($data['id']);
				// $attachmentDir = $mediaDirectory->getAbsolutePath($path_file . $resultFile['file']);
				$emailHepler = $this->_objectManager->create('Magebay\PrintLogo\Helper\Email');
				$pathTempFild = 'printlogo_send_mail_product_design'; 
				$emailTemplateVariables = ['customer_name' => $contact->getFirstName().' '.$contact->getLastName(), 'subject' => $data['subject'], 'message' => $data['message']];
				$senderInfo = ['email' => 'support@magebay.com', 'name' => 'Admin'];
				$receiverInfo = ['email' => $contact->getEmail(), 'name' => $contact->getFirstName().' '.$contact->getLastName()];
				$emailHepler->sendEmail($pathTempFild,$emailTemplateVariables,$senderInfo,$receiverInfo, $attachmentDir);
			}
		}catch (\Exception $e) {    
            $result = ['type'=>'error', 'alert'=>'Saved message errors. '.$e->getMessage()];
        }
		
        $resultJson = $this->_resultJsonFactory->create();
        // return $resultJson->setData([
			// $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result),
        // ]);
		return $resultJson->setData($result);
    }
    protected function _isAllowed()
    {
        return true;
    }
}