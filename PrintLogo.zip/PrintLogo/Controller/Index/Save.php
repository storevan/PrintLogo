<?php
/**
 * @Author      : TuanNA
 * @package     Marketplace_Seller_Business
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Controller\Index;

class Save extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	/**
     * @var \Magento\Customer\Model\Session
     */
	protected $_customerSession;
    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
     */
    protected $_printlogoFactory; 
         
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
        \Magebay\PrintLogo\Model\PrintLogo $printlogoFactory        
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->_customerSession = $customerSession;
        $this->_printlogoFactory = $printlogoFactory;           
        parent::__construct($context);
    }

    /**
     * Default customer account page
     *
     * @return void
     */
    public function execute()
    {
        try{
            $isseller = $this->_objectManager->get('Magebay\Marketplace\Helper\Data')->checkIsSeller();
            if($isseller){	
                $customerSession = $this->_customerSession;
                if($customerSession->isLoggedIn()){
                    $data = $this->getRequest()->getPostValue(); 
                    $business = $this->_printlogoFactory;
                    if($data['id']){
                        $business->load($data['id']);
                    }else{
                        $time = $this->_objectManager->create('Magento\Framework\Stdlib\DateTime\Timezone');
                        $business->setData('created_at', date('Y-m-d H:i:s',$time->scopeTimeStamp()));
                    }
                    $business->setData('seller_id', $this->_customerSession->getId());
                    $business->setData('longitude', $data['longitude']);
                    $business->setData('latitude', $data['latitude']);
                    $business->setData('zoom', $data['zoom']);
                    $business->setData('shop_location', $data['shop_location']);
                    $business->setData('status', $data['status']);
                    $business->save();
                }
            }  
            $msg = __('You saved successfully.');
            $this->messageManager->addSuccess( $msg );
            $this->_redirect( 'printlogo/index/view' );  
        }catch (\Exception $e) {    
            $this->messageManager->addError($e->getMessage()); 
            $this->_redirect( 'printlogo/index/view' );       
        }    
    } 
}