<?php
namespace Magebay\PrintLogo\Controller\Index;

class SaveRequest extends \Magento\Framework\App\Action\Action
{
	const LOGO = 'logo';
	const DESIGN = 'design';
	
    protected $resultPageFactory;
	protected $_contactFactory;
	protected $_requestFactory;
	protected $_attachmentFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magebay\PrintLogo\Model\ContactFactory $contactFactory,
		\Magebay\PrintLogo\Model\RequestFactory $requestFactory,
		\Magebay\PrintLogo\Model\AttachmentFactory $attachmentFactory,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
	{
		$this->resultPageFactory = $resultPageFactory;
		$this->_contactFactory = $contactFactory;
		$this->_requestFactory = $requestFactory;
		$this->_attachmentFactory = $attachmentFactory;
		parent::__construct($context);
	}

    public function execute()
    {
		try{
			$data = $this->getRequest()->getPostValue();
			$contact = $this->_contactFactory->create();
			$request = $this->_requestFactory->create();
			$time = $this->_objectManager->create('Magento\Framework\Stdlib\DateTime\Timezone');
			$result = ['success'=>true, 'message'=>'Send request successfully!'];
			
			/** save contact */
			$contact->addData($data);
			$contact->setData('created', date('Y-m-d H:i:s',$time->scopeTimeStamp()));
			$contact->setData('updated', date('Y-m-d H:i:s',$time->scopeTimeStamp()));
			$contact->setData('status', 1);
			$contact->save();
			
			/** save request */
			if($contact->getId()){
				$request->setData('contact_id', $contact->getId());
				$request->setData('reply_user_id', 0);
				$request->setData('message', $data['message']);
				$request->setData('created', date('Y-m-d H:i:s',$time->scopeTimeStamp()));
				$request->setData('status', 1);
				$request->save();
				
				/** save attachment */
				$logos = array();
				$designs = array();
				if(array_key_exists('logos', $data)){
					$logos = $data['logos'];
				}
				if(array_key_exists('designs', $data)){
					$designs = $data['designs'];
				}
				if($request->getId()){
					$path_file = 'Magebay/PrintLogo/Attachment';
					if(count($_FILES)){
						foreach($_FILES as $_itemfile=>$_itemfilevalue){
							if(!$_itemfilevalue['error']){
								$uploader = $this->_objectManager->create(
									'Magento\MediaStorage\Model\File\Uploader',
									['fileId' => $_itemfile]
								);

								$uploader->addValidateCallback('attachment_'.$_itemfile, $this, 'validateUploadFile');
								$uploader->setAllowRenameFiles(true);
								$uploader->setFilesDispersion(true);

								/** @var \Magento\Framework\Filesystem\Directory\Read $mediaDirectory */
								$mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
								$fileResult = $uploader->save($mediaDirectory->getAbsolutePath($path_file));
								$attachment = $this->_attachmentFactory->create();
								$attachment->setData('request_id', $request->getId());
								$attachment->setData('file_path', $path_file . $fileResult['file']);
								$attachment->setData('file_name', $_itemfilevalue['name']);
								if(in_array($_itemfile, $logos)){
									$attachment->setData('file_type', self::LOGO);
									$attachment->save();
								}
								if($_itemfilevalue['type'] == 'application/postscript'){
									$imagick = $this->_objectManager->create('Magebay\PrintLogo\Helper\Imagick');
									$imagick->setImagick($imagick->_openFile($mediaDirectory->getAbsolutePath($attachment->getData('file_path'))));
									$file_path = explode('.', $fileResult['file']);
									$file_name = explode('.', $_itemfilevalue['name']);
									$imagick->convertToPNG($mediaDirectory->getAbsolutePath($path_file.$file_path[0].'.png'));
									$attachment->setData('file_path', $path_file.$file_path[0].'.png');
									$attachment->setData('file_name', $file_name[0].'.png');
									$attachment->save();
								}
								// $attachment->setData('file_type', $_itemfilevalue['type']);
								// $attachment->save();
							}
						}
					}
					
					if(count($designs)){
						foreach($designs as $index=>$design){
							$mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
							if(!is_dir($mediaDirectory->getAbsolutePath($path_file))){
								mkdir($mediaDirectory->getAbsolutePath($path_file), 0777, true);
							}
							$this->base64_to_jpeg($design,$mediaDirectory->getAbsolutePath($path_file.'/design_'.$request->getId().'_'.$index.'.jpg'));
							$attachment = $this->_attachmentFactory->create();
							$attachment->setData('request_id', $request->getId());
							$attachment->setData('file_path', $path_file.'/design_'.$request->getId().'_'.$index.'.jpg');
							$attachment->setData('file_name', 'design_'.$request->getId().'_'.$index.'.jpg');
							$attachment->setData('file_type', self::DESIGN);
							$attachment->save();
						}
					}
				}
				else{
					$result = ['success'=>false, 'message'=>'Save request fail!'];
				}
			}
			else{
				$result = ['success'=>false, 'message'=>'Save contact fail!'];
			}
			$this->getResponse()->representJson(
				$this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result)
			);
		}catch (\Exception $e) {
			$this->getResponse()->representJson(
				$e->getMessage()
			);
        }
    }
	
	public function base64_to_jpeg($base64_string, $output_file) {
		$ifp = fopen($output_file, "wb"); 

		$data = explode(',', $base64_string);

		fwrite($ifp, base64_decode($data[1])); 
		fclose($ifp); 

		return $output_file; 
	}
}