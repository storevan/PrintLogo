<?php
/*
         M""""""""`M            dP                     
         Mmmmmm   .M            88                     
         MMMMP  .MMM  dP    dP  88  .dP   .d8888b.     
         MMP  .MMMMM  88    88  88888"    88'  `88     
         M' .MMMMMMM  88.  .88  88  `8b.  88.  .88     
         M         M  `88888P'  dP   `YP  `88888P'     
         MMMMMMMMMMM  [    -*- Magebay.com -*-   ]      
                                                       
         * * * * * * * * * * * * * * * * * * * * *     
         * -    - -    M.A.G.E.B.A.Y    - -    - *     
         * -  Copyright © 2010 - 2017 Magebay  - *     
         *    -  -  All Rights Reserved  -  -    *     
         * * * * * * * * * * * * * * * * * * * * *     
                                                     
*//**
 * --*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*-- *
 * @PROJECT    : Product Designer Pro 2016 [Magebay.com]
 * @AUTHOR     : Zuko
 * @COPYRIGHT  : © 2017 Magebay - Magento Ext Provider
 * @LINK       : https://www.magebay.com/
 * @FILE       : Imagick.php
 * @CREATED    : 1:43 PM , 15/Apr/2017
 * @DETAIL     :
 * --*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*-- *
**/


namespace Magebay\PrintLogo\Helper;

/**
 * Class Imagick
 * @package Pdp\Helper
 */
class Imagick {
    /** @var \Imagick  */
    protected $_imagick;

    /**
     * Imagick constructor.
     *
     * @param string $filePath
     */
    public function __construct()
    {
        if (!extension_loaded('imagick') || !class_exists("\\Imagick")) {
            throw new \RuntimeException('You need install Imagick PHP extension to use imagickHelper. FQN : ' . get_class($this));
        }
        // $this->_imagick = $this->_openFile($filePath);
    }
	
	public function setImagick($imagick){
		$this->_imagick = $imagick;
	}

    /**
     * @param string $filePath
     * @return \Imagick
     */
    public function _openFile($filePath)
    {
        $filePath = realpath($filePath);
        $ext = pathinfo($filePath, PATHINFO_EXTENSION);
        $supportedExt = \Imagick::queryFormats();
        if((!in_array($ext, $supportedExt) && !in_array(strtoupper($ext), $supportedExt))|| count($supportedExt) == 0)
        {
            
            throw new \RuntimeException(sprintf('PHP Imagick Ext loaded with no supported file extension format for "%s".
                     Look like the Image Magick Object Dependency is missing.',$ext));
        }
        return new \Imagick($filePath);
    }

    /**
     * @param string $savePath
     */
    public function convertToPNG($savePath)
    {
        $this->_imagick->setImageFormat('png');
        $this->_imagick->writeImage($savePath);
    }
}