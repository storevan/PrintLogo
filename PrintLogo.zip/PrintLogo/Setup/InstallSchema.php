<?php
/**
 * @Author      : TuanNA
 * @package     Magebay_PrintLogo
 * @copyright   Copyright (c) 2016 MAGEBAY (http://www.magebay.com)
 * @terms  http://www.magebay.com/terms
 * @license     http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 **/
namespace Magebay\PrintLogo\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        
		
        // Check if the table magebay_printlogo_contact already exists
        if ($installer->getConnection()->isTableExists($installer->getTable('magebay_printlogo_contact')) != true) {
            // Create magebay_printlogo_contact table
            $table = $installer->getConnection()->newTable(
                $installer->getTable('magebay_printlogo_contact')
            )->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'ID'
                )
				->addColumn(
                    'product_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Product ID'
                )
				->addColumn(
                    'session_id',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Session ID'
                )
                ->addColumn(
                    'business_name',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Business Name'
                )
				->addColumn(
                    'gender',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Gender'
                )
				->addColumn(
                    'first_name',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'First Name'
                )
				->addColumn(
                    'last_name',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Last Name'
                )
				->addColumn(
                    'street',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Strett'
                )
				->addColumn(
                    'zip_code',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'ZipCode'
                )
				->addColumn(
                    'city',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'City'
                )
				->addColumn(
                    'country_id',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Country ID'
                )
				->addColumn(
                    'email',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Email'
                )
				->addColumn(
                    'telephone',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Telephone'
                )
				->addColumn(
					'created',
					Table::TYPE_DATETIME,
					null,
					['nullable' => false, 'default' => '0000-00-00 00:00:00'],
					'Contact Creation Time'
				)
				->addColumn(
					'updated',
					Table::TYPE_DATETIME,
					null,
					['nullable' => false, 'default' => '0000-00-00 00:00:00'],
					'Contact Modification Time'
				)
                ->addColumn(
                    'status',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Status'
                )
                ->setComment('Magebay PrintLogo Contact')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
            $installer->getConnection()->createTable($table);
        }
		
		// Check if the table magebay_printlogo_request already exists
        if ($installer->getConnection()->isTableExists($installer->getTable('magebay_printlogo_request')) != true) {
            // Create magebay_printlogo_request table
            $table = $installer->getConnection()->newTable(
                $installer->getTable('magebay_printlogo_request')
            )->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'ID'
                )
				->addColumn(
                    'contact_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Contact ID'
                )
				->addColumn(
                    'reply_user_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Reply User ID'
                )
				->addColumn(
                    'subject',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Subject'
                )
				->addColumn(
                    'message',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Message'
                )
				->addColumn(
					'created',
					Table::TYPE_DATETIME,
					null,
					['nullable' => false, 'default' => '0000-00-00 00:00:00'],
					'Contact Creation Time'
				)
                ->addColumn(
                    'status',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Status'
                )
                ->setComment('Magebay PrintLogo Request')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
            $installer->getConnection()->createTable($table);
        }
		
		// Check if the table magebay_printlogo_attachment already exists
        if ($installer->getConnection()->isTableExists($installer->getTable('magebay_printlogo_attachment')) != true) {
            // Create magebay_printlogo_attachment table
            $table = $installer->getConnection()->newTable(
                $installer->getTable('magebay_printlogo_attachment')
            )->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'ID'
                )
				->addColumn(
                    'request_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Request ID'
                )
				->addColumn(
                    'file_path',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'Path'
                )
				->addColumn(
                    'file_name',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'File Name'
                )
				->addColumn(
                    'file_type',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => false, 'default' => ''],
                    'File Type'
                )
                ->setComment('Magebay PrintLogo Attachment')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
            $installer->getConnection()->createTable($table);
        }
        $setup->endSetup();
    }
}