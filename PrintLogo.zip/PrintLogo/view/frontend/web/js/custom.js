var _canvas;
var _canvasDisort;
var canvas;
var currentBg;
var typeImg = 1;
var isObjSelect = false;
var disorting = false;
var points = [[239, 212], [717, 212], [717, 893], [239, 893]];
var mainWindow = top.document;
var product_media_width = $(".product.media", mainWindow).width();
var product_id=$("input[name=product_id]", mainWindow).val();
var magebayMediaUrl;
var additionProperty = ['isBend','removeColor','object_type','isrc','isDisort'];
// dom ready
$(document).ready(function () {
  magebayMediaUrl = $("#magebay_media_url").val();
  initStorage();
var rotate_img = $("#rotate_img").val();
	var bending_img = $("#bending_img").val();
	var color_img = $("#color_img").val();
	var distort_img = $("#distort_img").val();
	var resize_img = $("#resize_img").val();
  fabric.Canvas.prototype.customiseControls({
    mtr: {
       action: 'rotate',
       cursor: 'pointer'
    },
    tr: {
      action: function(e, target) {
        document.getElementById('divRange').style.display = 'none';
        disortImg();
      },
      cursor: 'pointer'
    },
    bl: {
      action: function(e, target) {
        document.getElementById('divRange').style.display = 'none';
        openDialog();
      },
      cursor: 'pointer'
    },
    br: {
      action: 'scale',
      cursor: 'pointer'
    }
    ,
    tl: {
      action: function(e, target) {
        openDivRange();
      },
      cursor: 'pointer'
    }
  });
  fabric.Object.prototype.setControlsVisibility({
    mb: false,
    mr: false,
    ml: false,
    mt: false
  });
  fabric.Object.prototype.customiseCornerIcons({
    settings: {
      borderColor: '#00a1f0',
      cornerSize: 30,
      cornerShape: 'rect',
      //cornerBackgroundColor: '#00a1f0',
      cornerPadding: 1,
    },
    mtr: {
      icon: rotate_img
    },
    br: {
      icon: resize_img
    },
    bl: {
      icon: color_img
    },
    tr: {
      icon: distort_img
    },
    tl: {
      icon: bending_img
    }
  });
  
  $(window).load(function () {
    $('#loading').hide();
  });
  $(window).resize(function () {
    product_media_width = $(".product.media", mainWindow).width();
  });
  _canvas = new fabric.Canvas('canvas_side');
  _canvas.observe('object:selected', function (e) {
    isObjSelect = true;
    if(e.target.isBend && e.target.isBend != 0){
      document.getElementById('valueInput').value = e.target.isBend;
      bendImageUpdateValue(e.target.isBend);
    }else{
      document.getElementById('valueInput').value = 0;
      bendImageUpdateValue(0);
    }
  });
  _canvas.observe('before:selection:cleared', function (e) {
    isObjSelect = false;
  });
  _canvas.observe('object:modified', function (e) {
    createHistory();
  });
  _canvas.observe('object:removed', function (e) {
    createHistory();
  });
  _canvas.observe('object:rotate', function (e) {
  });
  /**
   ---TuanNA---
   ---Start---
   */
  $("#upload_logo_design", mainWindow).on("click", function () {
    $("#uploadLogo").click();
  });
  $("#bookmark").on("click", function () {
    $("#exportCanvas").click();
  });
  $("#btn_download_designed").on("click", function () {
    downloadImage();
  });
  $(mainWindow).on("click", ".logo_design_list li", function () {
    src = $(this).find("img").attr("src");
    addImageToCanvas(src, _canvas);
  });
  $(".submit_quote button", mainWindow).on("click", function () {
    var desingedList = $(".designed_list input:checked[name=designed]", mainWindow);
    if (desingedList.length > 0) {
      var html = '';
      desingedList.each(function (index, item) {
        html += '<li class="select">';
        html += '<input hidden type="checkbox" name="designs[]" value="' + $(item).val() + '" checked>';
		html += '<div class="icon_select" style="display:block;">';
		html += '<svg version="1.1" baseProfile="basic" class="ok-logo-tool_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 21.1 21.1" xml:space="preserve">';
		html += '<svg version="1.1" baseProfile="basic" class="ok-logo-tool_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 21.1 21.1" xml:space="preserve">';
		html += '<style type="text/css">.ok-logo-tool_svg_st0{fill:#fcb71b;}.ok-logo-tool_svg_st1{fill:#FFFFFF;}</style>';
		html += '<switch><g><g>';
		html += '<path class="ok-logo-tool_svg_st0" d="M10.6,0.1C4.8,0.1,0.1,4.8,0.1,10.6S4.8,21,10.6,21S21,16.3,21,10.6C21,4.9,16.4,0.1,10.6,0.1z"></path>';
		html += '<polygon class="ok-logo-tool_svg_st1" points="9.6,14.6 4.8,10.3 5.9,9.1 9.3,12.1 14.9,6.6 16.2,7.8 			"></polygon></g></g></switch></svg></div>';
        html += '<img src="' + $(item).val() + '">';
        html += '</li>';
      });
      $(".design_list", mainWindow).html(html);
      $(".design_list", mainWindow).parent().show();
      $("#open-request-logo-modal", mainWindow).click();
    }
  });
  $(".product_views li", mainWindow).on("click", function () {
    $('#loading').show();
    var iframeWidth = product_media_width;
    var iframeHeight = 0;
    var src = $(this).find('input[type=checkbox]').val();
    var img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = function () {
      // _canvas.setWidth(img.width);
      // _canvas.setHeight(img.height);
      iframeHeight = (parseFloat(iframeWidth) / parseFloat(img.width)) * parseFloat(img.height);
      $("#product-design-iframe", mainWindow).height(iframeHeight + 70);
      $("#product-design-iframe", mainWindow).width(iframeWidth);
      _canvas.setWidth(iframeWidth);
      _canvas.setHeight(iframeHeight);
      currentBg=img.src;
      _canvas.setBackgroundImage(img.src, _canvas.renderAll.bind(_canvas), {
        originX: 'left',
        originY: 'top',
        left: 0,
        top: 0,
        scaleY: parseFloat(iframeWidth) / parseFloat(img.width),
        scaleX: parseFloat(iframeWidth) / parseFloat(img.width),
      });
      $('#loading').hide();
    };
    img.src = src;
  });
  $(".product_views li", mainWindow).first().click();
  $("#load_logo_design", mainWindow).on("change", function () {
    var preview = document.getElementById('canvasImg'); //selects the query named img
    var file = $(this)[0].files[0]; //sames as here
    var reader = new FileReader();

    reader.onloadend = function () {
      preview.src = reader.result;
      addImageToCanvas(preview.src, _canvas);
      var selectedItem = $(".logo_design_list", mainWindow).find(".select");
      if (selectedItem.length > 0) {
        $(selectedItem).removeClass("select");
      }
      var html = '';
      html += '<li class="select">';
      html +='<div class="delete_action" onclick="">';
      html += '<svg version="1.1" baseProfile="basic" class="lt_delete_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 502 502" xml:space="preserve">';
      html += '<style type="text/css">';
      html += '.lt_delete_svg_st0{fill:#FFFFFF;}';
      html += '.lt_delete_svg_st1{fill:#B9B9B9;}';
      html += '.lt_delete_svg_st2{fill:#767676;}';
      html += '</style>';
      html += '<g><g>';
      html += '<path class="lt_delete_svg_st0" d="M251.8,487.9c130.4,0,236.1-105.7,236.1-236.1S382.2,15.7,251.8,15.7S15.7,121.4,15.7,251.8S121.4,487.9,251.8,487.9"/>';
      html += '<path class="lt_delete_svg_st1" d="M251.8,501.8c-137.8,0-250-112.1-250-250c0-137.8,112.2-250,250-250c137.9,0,250,112.2,250,250C501.8,389.7,389.7,501.8,251.8,501.8z M251.8,29.6c-122.5,0-222.2,99.7-222.2,222.2s99.7,222.2,222.2,222.2s222.2-99.7,222.2-222.2S374.4,29.6,251.8,29.6z"/>';
      html += '</g>';
      html += '<polygon class="lt_delete_svg_st2" points="333.4,181.5 310.5,160.2 254.2,220.8 198,160.2 175.1,181.5 232.9,243.7 175.1,306 198,327.3 254.2,266.7 310.5,327.3 333.4,306 275.5,243.7 	"/>';
      html += '</g></svg></div>';
      html += '<img src="' + reader.result + '">';
      html += '</li>';
      $(".logo_design_list", mainWindow).append(html);
    }

  if (file) {
    reader.readAsDataURL(file); //reads the data as a URL
  } else {
    preview.src = "";
  }
	$(".gallery-placeholder", mainWindow).hide();
	$("#product-design-logo", mainWindow).show();
	$('#open-load-design-logo-modal', mainWindow).attr("disabled", true);
	 var src = $(".attachment_list.select", mainWindow).find(".select").find("input[type=checkbox]").val();
	$(".product_views", mainWindow).find("input[type=checkbox][value='"+src+"']").parent().click();
	$("#open-remove-color-logo-modal", mainWindow).click();
	setTimeout(function(){
		openDialog();
	}, 1000);
 });
$(mainWindow).on("click", ".remove-color-logo-popup .modal-footer button", function(){
	var iframeRemoveColor = $("#remove-color-iframe", mainWindow);
	typeImg = iframeRemoveColor.contents().find("#typeImg").val();
	var dataURL = iframeRemoveColor.contents().find("#imgOrigin").attr("src");
	if (typeImg == 2) {
		dataURL = iframeRemoveColor.contents().find("#imgRemoveBg").attr("src");
	} else if (typeImg == 3) {
		dataURL = iframeRemoveColor.contents().find("#imgColorRemove").attr("src");
	}
	var options = {
	isBend: 0,
	removeColor: true
	};
	replaceImageToCanvas(dataURL, options, _canvas);
 });
  /**
   ---TuanNA---
   ----End----
   */
});

function bendImageUpdateValue(percent) {
  document.getElementById('textInput').innerHTML = percent + '%';
}

function bendImage(percent, isBend, newSrc) {
  if (!isObjSelect)
    return false;
  document.getElementById('textInput').innerHTML = percent + '%';
  $('#loading').show();
  canvas = document.getElementById('myCanvas');
  var context = canvas.getContext('2d');
  image = new Image();
  image.crossOrigin = 'anonymous';
  $(image).load(function () {
    canvas.width = image.width;
    canvas.height = image.height + parseInt(percent);
    if (parseInt(percent) < 0) {
      canvas.height = image.height - parseInt(percent);
    }
    var x1 = image.width / 2;
    var x2 = image.width;
    var y1 = parseInt(percent); // curve depth
    var y2 = 0;

    var eb = (y2 * x1 * x1 - y1 * x2 * x2) / (x2 * x1 * x1 - x1 * x2 * x2);
    var ea = (y1 - eb * x1) / (x1 * x1);

// variable used for the loop
    var currentYOffset;

    for (var x = 0; x < image.width; x++) {
      // calculate the current offset 
      currentYOffset = (ea * x * x) + eb * x;
      if (parseInt(percent) < 0) {
        currentYOffset = currentYOffset - parseInt(percent);
      }
      context.drawImage(image, x, 0, 1, image.height, x, currentYOffset, 1, image.height);
    }
    setTimeout(
            function () {
              var dataURL = canvas.toDataURL();
              //document.getElementById("canvasImg").style.display='block';
              //document.getElementById('canvasImg').src = dataURL;
              var options = {
                isBend: percent
              };
              var activeObj = _canvas.getActiveObject();
              if (activeObj && activeObj.removeColor && activeObj.removeColor == true) {
                options['removeColor'] = true;
              } else if (isBend) {
                options['removeColor'] = true;
              }
              replaceImageToCanvas(dataURL, options, _canvas);
              $('#loading').hide();
               document.getElementById('divRange').style.display = 'none';
            }, 3000);
  });
  if (isBend) {
    $(image).attr('src', newSrc);
  } else {
    var activeObj = _canvas.getActiveObject();
    if (activeObj && activeObj.removeColor && activeObj.removeColor == true) {
      $(image).attr('src', activeObj.isrc);
    } else if (activeObj && activeObj.isDisort && activeObj.isDisort == true) {
      $(image).attr('src', activeObj.isrc);
    } else if(activeObj){
      $(image).attr('src', activeObj.isrc);
    }else{
      $(image).attr('src', document.getElementById('canvasImg').src);
    }
  }
}

function openDivRange() {
  var activeObj = _canvas.getActiveObject();
  if (!activeObj)
    return false;
  if (disorting)
    return false;
  if(document.getElementById('divRange').style.display=='none'){
    if (activeObj && activeObj.isBend && activeObj.isBend != 0) {
      document.getElementById('valueInput').value = activeObj.isBend;
    } else {
      document.getElementById('valueInput').value = 0;
    }
    $('#divRange').css({top: activeObj.top, left: activeObj.left-50, position:'absolute'});
    document.getElementById('divRange').style.display = 'block';
  }else{
    document.getElementById('divRange').style.display = 'none';
  }
}

function addImageToCanvas(src, _canvas) {
  if (src && _canvas) {
    // TuanNA
    _canvas._objects = [];
    // TuanNA
    fabric.Image.fromURL(src, function (image) {
      image.set({
        isrc: src,
        scaleY: (_canvas.width / image.width / 2) / _canvas.getZoom(),
        scaleX: (_canvas.width / image.width / 2) / _canvas.getZoom(),
        object_type: 'image',
        centeredScaling: true,
        padding: 0,
        hasRotatingPoint: true
      });
      image.setCoords();
      _canvas.centerObject(image);
      _canvas.add(image);
      _canvas.setActiveObject(image).renderAll();
      createHistory();
    });
  }
}

function replaceImageToCanvas(src, option, _canvas) {
  if (src && _canvas) {
    var activeObj = _canvas.getActiveObject();
    fabric.Image.fromURL(src, function (image) {
      var img = {
        left: activeObj.getLeft(),
        top: activeObj.getTop(),
        scaleY: activeObj.scaleY,
        scaleX: activeObj.scaleX,
        isrc: src,
        isBend: option.isBend || 0,
        removeColor: option.removeColor || false,
        visible: option.visible || true,
        object_type: 'image',
        centeredScaling: true,
        padding: 0,
        hasRotatingPoint: true
      };
      image.set(img);
      image.setAngle(activeObj.getAngle()).setCoords();
      _canvas.add(image).setActiveObject(image);
      _canvas.remove(activeObj);
      _canvas.renderAll();
      createHistory();
    });
  }
}

function replaceImageDisortToCanvas(src, option, _canvas) {
  if (src && _canvas) {
    var activeObj = _canvas.getActiveObject();
    var left = points[0][0];
    var top = points[0][1];
    if (top > points[1][1]) {
      top = points[1][1];
    }
    if (top > points[2][1]) {
      top = points[2][1];
    }
    if (top > points[3][1]) {
      top = points[3][1];
    }
    if (left > points[1][0]) {
      left = points[1][0];
    }
    if (left > points[2][0]) {
      left = points[2][0];
    }
    if (left > points[3][0]) {
      left = points[3][0];
    }
    fabric.Image.fromURL(src, function (image) {
      var img = {
        left: left,
        top: top,
        scaleY: 1,
        scaleX: 1,
        isrc: src,
        isBend: option.isBend || 0,
        isDisort: option.isDisort || false,
        removeColor: option.removeColor || false,
        visible: true,
        hasControls: true,
        object_type: 'image',
        padding: 0,
        hasRotatingPoint: true
      };
      image.set(img);
      //image.setAngle(activeObj.getAngle()).setCoords();
      _canvas.add(image).setActiveObject(image);
      _canvas.remove(activeObj);
      _canvas.renderAll();
    });
  }
}

function openDialog() {
  var iframeRemoveColor = $("#remove-color-iframe", mainWindow);
	var activeObj = _canvas.getActiveObject();
	iframeRemoveColor.contents().find("#loadingDialog").show();
	if (!activeObj) return false;
	if(disorting) return false;
	iframeRemoveColor.contents().find("#imgOrigin").hide();
	iframeRemoveColor.contents().find("#imgRemoveBg").hide();
	iframeRemoveColor.contents().find("#imgColorRemove").hide();
        if(activeObj.isrc){
          removeWhiteColor(activeObj.isrc);
        }
        $("#open-remove-color-logo-modal", mainWindow).click();
	setTimeout(function(){
		iframeRemoveColor.contents().find("#imgOrigin").attr("src", activeObj.isrc);
		iframeRemoveColor.contents().find("#imgRemoveBg").attr("src", canvas.toDataURL());
		iframeRemoveColor.contents().find("#imgColorRemove").attr("src", activeObj.isrc);
		initColorPick();
		iframeRemoveColor.contents().find("#imgOrigin").show();
		iframeRemoveColor.contents().find("#imgRemoveBg").show();
		iframeRemoveColor.contents().find("#imgColorRemove").show();
                setTimeout(function(){
                  var height = iframeRemoveColor.contents().find("html").height(); 
                  iframeRemoveColor.height(height+20);
                  iframeRemoveColor.contents().find("#loadingDialog").hide();
                }, 100);
	}, 2000);
}

function removeWhiteColor(imgSrc) {
  canvas = document.getElementById("myCanvas"),
          ctx = canvas.getContext("2d"),
          image = new Image();
  image.crossOrigin = 'anonymous';
  $(image).load(function () {
    canvas.width = image.width;
    canvas.height = image.height;
    ctx.drawImage(image, 0, 0);

    var imgd = ctx.getImageData(0, 0, image.width, image.height),
            pix = imgd.data,
            newColor = {r: 0, g: 0, b: 0, a: 0};

    for (var i = 0, n = pix.length; i < n; i += 4) {
      var r = pix[i],
              g = pix[i + 1],
              b = pix[i + 2];
      if (r === 255 && g === 255 && b === 255) {
        // Change the white to the new color.
        pix[i] = newColor.r;
        pix[i + 1] = newColor.g;
        pix[i + 2] = newColor.b;
        pix[i + 3] = newColor.a;
      }
    }
    ctx.putImageData(imgd, 0, 0);
    
  });
  $(image).attr('src', imgSrc);
}

function removeAnotherColor(rgb) {
  var activeObj = _canvas.getActiveObject();
  if (!activeObj)
    return false;
  canvas = document.getElementById("myCanvas"),
          ctx = canvas.getContext("2d"),
          image = new Image();
  image.crossOrigin = 'anonymous';
  $(image).load(function () {
    canvas.width = image.width;
    canvas.height = image.height;
    ctx.drawImage(image, 0, 0);

    var imgd = ctx.getImageData(0, 0, image.width, image.height),
            pix = imgd.data,
            newColor = {r: 0, g: 0, b: 0, a: 0};

    for (var i = 0, n = pix.length; i < n; i += 4) {
      var r = pix[i],
              g = pix[i + 1],
              b = pix[i + 2];

      if (r == rgb[0] && g == rgb[1] && b == rgb[2]) {
        // Change the white to the new color.
        pix[i] = newColor.r;
        pix[i + 1] = newColor.g;
        pix[i + 2] = newColor.b;
        pix[i + 3] = newColor.a;
      }
    }
    ctx.putImageData(imgd, 0, 0);
    setTimeout(
            function () {
		// TuanNA
		var iframeRemoveColor = $("#remove-color-iframe", mainWindow);
		iframeRemoveColor.contents().find("#imgColorRemove").attr("src", canvas.toDataURL());
              // document.getElementById('imgColorRemove').src = canvas.toDataURL();
            }, 2000);
  });
  $(image).attr('src', activeObj.isrc);
}


function useCanvas(el, image, callback) {
  el.width = image.width; // img width
  el.height = image.height; // img height
  // draw image in canvas tag
  el.getContext('2d')
          .drawImage(image, 0, 0, image.width, image.height);
  return callback();
}

function initColorPick() {
	var iframeRemoveColor = $("#remove-color-iframe", mainWindow);
  // var img = document.getElementById('imgColorRemove', mainWindow),
  var img = iframeRemoveColor.contents().find("#imgColorRemove")[0],
          canvasPick = iframeRemoveColor.contents().find('#canvasColor')[0],
          x, y;
  if (img !== null) {
    img.addEventListener('mousemove', function (e) {
      // chrome
      if (e.offsetX) {
        x = e.offsetX;
        y = e.offsetY;
      }
      // firefox
      else if (e.layerX) {
        x = e.layerX;
        y = e.layerY;
      }
      useCanvas(canvasPick, img, function () {
        var p = canvasPick.getContext('2d')
                .getImageData(x, y, 1, 1).data;
        // show preview color
//        console.log(p[0], p[1], p[2]);
      });
    }, false);
    img.addEventListener('click', function (e) {
		iframeRemoveColor.contents().find("#loadingDialog").show();
      // $('#loadingDialog').show();
      var x, y,
              canvasPick = iframeRemoveColor.contents().find('#canvasColor')[0],
			  img = iframeRemoveColor.contents().find("#imgColorRemove")[0];
              // img = document.getElementById('imgColorRemove');
      if (e.offsetX) {
        x = e.offsetX;
        y = e.offsetY;
      }
      // firefox
      else if (e.layerX) {
        x = e.layerX;
        y = e.layerY;
      }
      useCanvas(canvasPick, img, function () {
        // get image data
        var p = canvasPick.getContext('2d')
                .getImageData(x, y, 1, 1).data;
        console.log(p);
        removeAnotherColor(p);
		iframeRemoveColor.contents().find("#loadingDialog").hide();
        // $('#loadingDialog').hide();
      });
    }, false);
  }
}
function changeSelect(type) {
  typeImg = type;
}
function exportCanvas() {
  if (disorting)
    return false;
  document.getElementById('divRange').style.display = 'none';
  document.getElementById("canvas_distort").style.display = 'none';
  document.getElementById("disortOk").style.display = 'none';
  disorting = false;
  var d = _canvas.toDataURL("image/png");
  var jsonContent= _canvas.toJSON(additionProperty);
  jsonContent.previewDesign=d;
  var numDesign=0;
  if(localStorage.getItem(product_id)){
    if(JSON.parse(localStorage.getItem(product_id)).design.length>0){
      numDesign=JSON.parse(localStorage.getItem(product_id)).design.length;
      var arrDesign=JSON.parse(localStorage.getItem(product_id)).design;
      arrDesign.push(jsonContent);
    }else{
      var arrDesign=[jsonContent];
    }
    var json={
      design:arrDesign
    };
    localStorage.setItem(product_id,JSON.stringify(json));
  }else{
    var arrDesign=[jsonContent];
    var json={
      design:arrDesign
    };
    localStorage.setItem(product_id,JSON.stringify(json));
  }
  
  /**
   ---TuanNA---
   ---Start---
   */
  var html = '';
  html += '<li>';
  html += '<div class="delete_action" onclick="">';
  html += '<input type="hidden" name="design_value" value="' + numDesign + '">';
  html += '<svg version="1.1" baseProfile="basic" class="lt_delete_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 502 502" xml:space="preserve">';
  html += '<style type="text/css">';
  html += '.lt_delete_svg_st0{fill:#FFFFFF;}';
  html += '.lt_delete_svg_st1{fill:#B9B9B9;}';
  html += '.lt_delete_svg_st2{fill:#767676;}';
  html += '</style>';
  html += '<g><g>';
  html += '<path class="lt_delete_svg_st0" d="M251.8,487.9c130.4,0,236.1-105.7,236.1-236.1S382.2,15.7,251.8,15.7S15.7,121.4,15.7,251.8S121.4,487.9,251.8,487.9"/>';
  html += '<path class="lt_delete_svg_st1" d="M251.8,501.8c-137.8,0-250-112.1-250-250c0-137.8,112.2-250,250-250c137.9,0,250,112.2,250,250C501.8,389.7,389.7,501.8,251.8,501.8z M251.8,29.6c-122.5,0-222.2,99.7-222.2,222.2s99.7,222.2,222.2,222.2s222.2-99.7,222.2-222.2S374.4,29.6,251.8,29.6z"/>';
  html += '</g>';
  html += '<polygon class="lt_delete_svg_st2" points="333.4,181.5 310.5,160.2 254.2,220.8 198,160.2 175.1,181.5 232.9,243.7 175.1,306 198,327.3 254.2,266.7 310.5,327.3 333.4,306 275.5,243.7 	"/>';
  html += '</g></svg></div>';
  html += '<img src="' + d + '">';
  html += '</li>';
  $(".designed_list", mainWindow).append(html);
  /**
   ---TuanNA---
   ---End---
   */
}

function initStorage(){
   if(localStorage.getItem(product_id)){
      var json=JSON.parse(localStorage.getItem(product_id));
       //load design from storage
       if(json.design.length>0){
         for (var i = 0; i < json.design.length; i++) { 
            var html = '';
            html += '<li>';
            html +='<div class="delete_action" onclick="">';
            html += '<input type="hidden" name="design_value" value="' + i + '">';
            html +='<svg version="1.1" baseProfile="basic" class="lt_delete_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 502 502" xml:space="preserve">';
            html +='<style type="text/css">';
            html +='.lt_delete_svg_st0{fill:#FFFFFF;}';
            html +='.lt_delete_svg_st1{fill:#B9B9B9;}';
            html +='.lt_delete_svg_st2{fill:#767676;}';
            html +='</style>';
            html +='<g><g>';
            html +='<path class="lt_delete_svg_st0" d="M251.8,487.9c130.4,0,236.1-105.7,236.1-236.1S382.2,15.7,251.8,15.7S15.7,121.4,15.7,251.8S121.4,487.9,251.8,487.9"/>';
            html +='<path class="lt_delete_svg_st1" d="M251.8,501.8c-137.8,0-250-112.1-250-250c0-137.8,112.2-250,250-250c137.9,0,250,112.2,250,250C501.8,389.7,389.7,501.8,251.8,501.8z M251.8,29.6c-122.5,0-222.2,99.7-222.2,222.2s99.7,222.2,222.2,222.2s222.2-99.7,222.2-222.2S374.4,29.6,251.8,29.6z"/>';
            html +='</g>';
            html +='<polygon class="lt_delete_svg_st2" points="333.4,181.5 310.5,160.2 254.2,220.8 198,160.2 175.1,181.5 232.9,243.7 175.1,306 198,327.3 254.2,266.7 310.5,327.3 333.4,306 275.5,243.7 	"/>';
            html +='</g></svg></div>';
            html += '<img src="' + json.design[i].previewDesign + '">';
            html += '</li>';
            $(".designed_list", mainWindow).append(html);
         }
       }
   }
}

$(mainWindow).on("click", ".designed_list li", function () {
    var value = $(this).find("input[name=design_value]").val();
    if(localStorage.getItem(product_id)){
      var json=JSON.parse(localStorage.getItem(product_id)).design[value];
      if(json){
          _canvas.loadFromJSON(json, function () {
          _canvas.renderAll();
        });
      }
    }
  });
  
$(mainWindow).on("click", ".logo_design_list li .delete_action", function () {
      if(confirm("Do you want delete this logo?")){
        $(this).parent().remove();
      }
  });  
  
$(mainWindow).on("click", ".designed_list li .delete_action", function () {
    var value = $(this).find("input").val();
    if(localStorage.getItem(product_id)){
      if(confirm("Do you want delete this design?")){
        var json=JSON.parse(localStorage.getItem(product_id));
        json.design.splice(value,1);  
        localStorage.setItem(product_id,JSON.stringify(json));
        $(".designed_list", mainWindow).html('');
        initStorage();
      }
    }
  });

function uploadImage() {
  var preview = document.getElementById('canvasImg'); //selects the query named img
  var file = document.getElementById('uploadLogo').files[0]; //sames as here
  var imgExtensions = ["image/jpg", "image/jpeg", "image/png", "image/svg+xml", "application/postscript"];
  if($.inArray(file.type, imgExtensions) !== -1){
   var reader = new FileReader();
    reader.onloadend = function () {

      preview.src = reader.result;
      addImageToCanvas(preview.src, _canvas);
      /**
       ---TuanNA---
       ---Start---
       */
      var selectedItem = $(".logo_design_list", mainWindow).find(".select");
      if (selectedItem.length > 0) {
        $(selectedItem).removeClass("select");
      }
      var html = '';
      html += '<li class="select">';
      html +='<div class="delete_action" onclick="">';
      html += '<svg version="1.1" baseProfile="basic" class="lt_delete_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 502 502" xml:space="preserve">';
      html += '<style type="text/css">';
      html += '.lt_delete_svg_st0{fill:#FFFFFF;}';
      html += '.lt_delete_svg_st1{fill:#B9B9B9;}';
      html += '.lt_delete_svg_st2{fill:#767676;}';
      html += '</style>';
      html += '<g><g>';
      html += '<path class="lt_delete_svg_st0" d="M251.8,487.9c130.4,0,236.1-105.7,236.1-236.1S382.2,15.7,251.8,15.7S15.7,121.4,15.7,251.8S121.4,487.9,251.8,487.9"/>';
      html += '<path class="lt_delete_svg_st1" d="M251.8,501.8c-137.8,0-250-112.1-250-250c0-137.8,112.2-250,250-250c137.9,0,250,112.2,250,250C501.8,389.7,389.7,501.8,251.8,501.8z M251.8,29.6c-122.5,0-222.2,99.7-222.2,222.2s99.7,222.2,222.2,222.2s222.2-99.7,222.2-222.2S374.4,29.6,251.8,29.6z"/>';
      html += '</g>';
      html += '<polygon class="lt_delete_svg_st2" points="333.4,181.5 310.5,160.2 254.2,220.8 198,160.2 175.1,181.5 232.9,243.7 175.1,306 198,327.3 254.2,266.7 310.5,327.3 333.4,306 275.5,243.7 	"/>';
      html += '</g></svg></div>';
      html += '<img src="' + reader.result + '">';
      html += '</li>';
      $(".logo_design_list", mainWindow).append(html);
      /**
       ---TuanNA---
       ---End---
       */
    } 

    if (file) {
      reader.readAsDataURL(file); //reads the data as a URL
    } else {
      preview.src = "";
    }
  }else{
    alert('Error in updating logo image - Invalid image type');
  }
}

function deleteImg(){
  document.getElementById('divRange').style.display = 'none';
  document.getElementById("canvas_distort").style.display = 'none';
  document.getElementById("disortOk").style.display = 'none';
  disorting = false;
  var activeObj = _canvas.getActiveObject();
  if (activeObj) {
    _canvas.remove(activeObj);
    _canvas.renderAll();
  }
}

function disortImg() {
  if (disorting)
    return false;
  var activeObj = _canvas.getActiveObject();
  if (activeObj) {
    disorting = true;
    points = [[activeObj.oCoords.tl.x, activeObj.oCoords.tl.y], [activeObj.oCoords.tr.x, activeObj.oCoords.tr.y], [activeObj.oCoords.br.x, activeObj.oCoords.br.y], [activeObj.oCoords.bl.x, activeObj.oCoords.bl.y]];
    prepareDisort();
    document.getElementById("canvas_distort").style.display = 'block';
    document.getElementById("disortOk").style.display = 'block';
    activeObj.visible = false;
    activeObj.hasControls = false;
    $('#disortOk').css({top: points[2][1]+20, left: points[2][0]+20, position:'absolute'});
    //_canvas.deactivateAll();
    _canvas.renderAll();
  }
}

/**
 ---TuanNA---
 ---Start---
 */
function downloadImage() {
  if (disorting)
    return false;
  document.getElementById('divRange').style.display = 'none';
  document.getElementById("canvas_distort").style.display = 'none';
  document.getElementById("disortOk").style.display = 'none';
  disorting = false;
  var d = _canvas.toDataURL("image/png");
  var linkDown = document.createElement('a');
  linkDown.setAttribute('href', d);
  linkDown.setAttribute('target', '_blank');
  linkDown.setAttribute('download', 'download.png');
  document.body.appendChild(linkDown);
  linkDown.click();
}
/**
 ---TuanNA---
 ---End---
 */

function getMaxWidth() {
  var point0X = points[0][0];
  var point1X = points[1][0];
  var point2X = points[2][0];
  var point3X = points[3][0];
  var maxLeft = point0X;
  if (point1X > maxLeft) {
    maxLeft = point1X;
  }
  if (point2X > maxLeft) {
    maxLeft = point2X;
  }
  if (point3X > maxLeft) {
    maxLeft = point3X;
  }
  var minLeft = point0X;
  if (point1X < minLeft) {
    minLeft = point1X;
  }
  if (point2X < minLeft) {
    minLeft = point2X;
  }
  if (point3X < minLeft) {
    minLeft = point3X;
  }
  var maxW = maxLeft - minLeft;
  return maxW;
}

function getMaxHeight() {
  var point0Y = points[0][1];
  var point1Y = points[1][1];
  var point2Y = points[2][1];
  var point3Y = points[3][1];
  var maxTop = point0Y;
  if (point1Y > maxTop) {
    maxTop = point1Y;
  }
  if (point2Y > maxTop) {
    maxTop = point2Y;
  }
  if (point3Y > maxTop) {
    maxTop = point3Y;
  }
  var minTop = point0Y;
  if (point1Y < minTop) {
    minTop = point1Y;
  }
  if (point2Y < minTop) {
    minTop = point2Y;
  }
  if (point3Y < minTop) {
    minTop = point3Y;
  }
  var maxH = maxTop - minTop;
  return maxH;
}

function addToDesign() {
  setTimeout(
          function () {
            //add to fabric js
            var activeObj = _canvas.getActiveObject();
            if (activeObj) {

              var resizedCanvas = document.createElement("canvas");
              var resizedContext = resizedCanvas.getContext("2d");

              var maxW = getMaxWidth();
              var maxH = getMaxHeight();


              resizedCanvas.width = maxW;
              resizedCanvas.height = maxH;

              var clipX = points[0][0];
              if (clipX > points[1][0]) {
                clipX = points[1][0];
              }
              if (clipX > points[2][0]) {
                clipX = points[2][0];
              }
              if (clipX > points[3][0]) {
                clipX = points[3][0];
              }
              var clipY = points[0][1];
              if (clipY > points[1][1]) {
                clipY = points[1][1];
              }
              if (clipY > points[2][1]) {
                clipY = points[2][1];
              }
              if (clipY > points[3][1]) {
                clipY = points[3][1];
              }
              
              var x = resizedCanvas.width / 2;
              var y = resizedCanvas.height / 2;
			  
              
              //resizedContext.translate(x, y);
              //resizedContext.rotate(-activeObj.getAngle() * Math.PI / 180);
              //resizedContext.translate(-x, -y);
              
              resizedContext.drawImage(_canvasDisort, clipX, clipY, resizedCanvas.width, resizedCanvas.height, 0, 0, resizedCanvas.width, resizedCanvas.height);
              var myResizedData = resizedCanvas.toDataURL();
            }
//            document.getElementById("canvasImg").style.display='block';
//            document.getElementById("canvasImg").src=myResizedData;
            document.getElementById("canvas_distort").style.display = 'none';
            document.getElementById("disortOk").style.display = 'none';
            disorting = false;
            var options = {
              isDisort: true
            };
            replaceImageDisortToCanvas(myResizedData, options, _canvas);
          }, 1000);
}

function prepareDisort() {
  var activeObj = _canvas.getActiveObject();
  if (!activeObj)
    return false;

  var canvas = document.getElementById("canvas_distort");
  canvas.width = _canvas.width;
  canvas.height = _canvas.height;
  var ctx = canvas.getContext('2d');
  var canvas1 = document.createElement('canvas');
  _canvasDisort = canvas1;
  canvas1.width = canvas.width;
  canvas1.height = canvas.height;
  var ctx1 = canvas1.getContext('2d');
  var canvas2 = document.createElement('canvas');
  canvas2.width = canvas.width;
  canvas2.height = canvas.height;
  var ctx2 = canvas2.getContext('2d');
  //
  var op = null;
  var img = new Image();

  if (activeObj && activeObj.isrc) {
//    if(activeObj.angle>0){
//      img.src = activeObj.toDataURL();
//    }else{
      img.src = activeObj.isrc;
//    }
  } else {
    img.src = document.getElementById("canvasImg").src;
  }


  img.onload = function () {
    op = new Perspective(ctx1, img);
    $('#loading').show();
    setTimeout(function () {
      op.draw(points,activeObj);
      prepare_lines(ctx2, points);
      draw_canvas(ctx, ctx1, ctx2);
      $('#loading').hide();
    }, 20);
  };
  var drag = null;
  canvas.addEventListener("mousedown", function (event) {
    event.preventDefault();
    var p = get_mouse_position(event);
    for (var i = 0; i < 4; i++) {
      var x = points[i][0];
      var y = points[i][1];
      if (p.x < x + 10 && p.x > x - 10 && p.y < y + 10 && p.y > y - 10) {
        drag = i;
        break;
      }
    }
  }, false);
  canvas.addEventListener("mousemove", function (event) {
    event.preventDefault();
    if (drag == null) {
      return;
    }
    var p = get_mouse_position(event);
    points[drag][0] = p.x;
    points[drag][1] = p.y;
    prepare_lines(ctx2, points, true);
    draw_canvas(ctx, ctx1, ctx2);
  }, false); 
  canvas.addEventListener("mouseup", function (event) {
    event.preventDefault();
    if (drag == null) {
      return;
    }
    $('#loading').show();
    var s = (new Date()).getTime();
    var p = get_mouse_position(event);
    points[drag][0] = p.x;
    points[drag][1] = p.y;
    setTimeout(function () {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx1.clearRect(0, 0, canvas.width, canvas.height);
      op.draw(points,activeObj);
      prepare_lines(ctx2, points);
      draw_canvas(ctx, ctx1, ctx2);
      $('#loading').hide();
    }, 10);
    if(drag===2){
      $('#disortOk').css({top: points[2][1]+10, left: points[2][0]+10, position:'absolute'});
    }
    drag = null;
  }, false);
  canvas.addEventListener("mouseout", function (event) {
    event.preventDefault();
    drag = null;
  }, false);
  canvas.addEventListener("mouseenter", function (event) {
    event.preventDefault();
    drag = null;
  }, false);
}
//(function () {
//window.addEventListener("load", function() {


//}, false);

function prepare_lines(ctx, p, with_line) {
  ctx.save();
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  //ctx.clearRect(0, 0, 600, 450);
  //
  if (with_line == true) {
    ctx.beginPath();
    ctx.moveTo(p[0][0], p[0][1]);
    for (var i = 1; i < 4; i++) {
      ctx.lineTo(p[i][0], p[i][1]);
    }
    ctx.closePath();
    ctx.strokeStyle = "red";
    ctx.stroke();
  }
  //
  ctx.fillStyle = "red";
  for (var i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.arc(p[i][0], p[i][1], 10, 0, Math.PI * 2, true);
    ctx.fill();
  }
  //
  ctx.restore();
}

function draw_canvas(ctx, ctx1, ctx2) {
//  var activeObj = _canvas.getActiveObject();
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
//  var x = ctx1.canvas.width / 2;
//  var y = ctx1.canvas.height / 2;
//  ctx1.translate(x, y);
//  ctx1.rotate(activeObj.getAngle() * Math.PI / 180);
  ctx.drawImage(ctx1.canvas, 0, 0);
//  ctx1.rotate(-activeObj.getAngle() * Math.PI / 180);
//  ctx1.translate(-x, -y);
  ctx.drawImage(ctx2.canvas, 0, 0);
}

function get_mouse_position(event) {
  var rect = event.target.getBoundingClientRect();
  return {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top
  };
}

/****************UNDO REDO--------*/
var undoManager = new UndoManager(),
	hisId= 1,
    historyItems = {},
    addHistory,
    removeHistory,
	drawDesign,
	undoAction,
	redoAction,
    createHistory;
undoManager.clear();
undoManager.setLimit(10);	

addHistory = function(hisId, content) {
    historyItems[hisId] = content;
};

removeHistory = function(hisId) {
    delete historyItems[hisId];
};

drawDesign=function(canvas, json, callback) {
                    if(canvas && json) {
                       if(json.backgroundImage){
                          json.backgroundImage.src=currentBg;
                        }
                        canvas.loadFromJSON(json, function() {
                            canvas.renderAll();
                            callback && callback();
                        });
                    }
                },

createHistory = function () {
	var historyId = hisId++;
	var jsonContent = _canvas.toJSON(additionProperty);
    // first creation
    addHistory(historyId, jsonContent);
    // make undo-able
	 if(undoManager) {
		undoManager.add({
			undo: function() {
				drawDesign(_canvas, historyItems[historyId], function() {
                                  removeHistory(historyId);
				});
			},
			redo: function() {
				addHistory(historyId, jsonContent);
				drawDesign(_canvas, historyItems[historyId]);
			}
		});
	 }
	 showAndHideUndoRedoBtn();
};
showAndHideUndoRedoBtn = function () {
  if (!undoManager.hasUndo()) {
    $("#btnUndo").prop("disabled", true);
  } else {
    $("#btnUndo").prop("disabled", false);
  }
  if (!undoManager.hasRedo()) {
    $("#btnRedo").prop("disabled", true);
  } else {
    $("#btnRedo").prop("disabled", false);
  }
};
undoAction = function () {
  document.getElementById('divRange').style.display = 'none';
  document.getElementById("canvas_distort").style.display = 'none';
  document.getElementById("disortOk").style.display = 'none';
  disorting = false;
  if (undoManager) {
    undoManager.undo();
  }
  showAndHideUndoRedoBtn();
};
redoAction = function () {
  document.getElementById('divRange').style.display = 'none';
  document.getElementById("canvas_distort").style.display = 'none';
  document.getElementById("disortOk").style.display = 'none';
  disorting = false;
  if (undoManager) {
    undoManager.redo();
  }
  showAndHideUndoRedoBtn();
};
//})();