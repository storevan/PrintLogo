function changeSelect(type){
	$("#typeImg").val(type);
}